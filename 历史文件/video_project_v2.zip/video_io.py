# video_io.py

import subprocess

def extract_segment(src, start, end, dest):
    cmd = [
        'ffmpeg', '-y', '-ss', str(start), '-to', str(end), '-i', src,
        '-c', 'copy', dest
    ]
    subprocess.run(cmd, check=True)

def crop_and_pad(src, crop_box, dest):
    x1, y1, x2, y2 = crop_box
    crop_w = x2 - x1
    crop_h = y2 - y1
    out_h = crop_h
    out_w = int(out_h * 9/16)
    vf = (
        f"crop={crop_w}:{crop_h}:{x1}:{y1},"
        f"scale={out_w}:{out_h},"
        f"pad=iw:ih*16/9:(ow-iw)/2:(oh-ih)/2:black"
    )
    cmd = [
        'ffmpeg', '-y', '-i', src,
        '-vf', vf,
        '-c:v', 'libx264', '-c:a', 'copy', dest
    ]
    subprocess.run(cmd, check=True)

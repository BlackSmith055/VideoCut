# VideoProject

## 项目结构
```
video_project/
├── main_workflow.py    # 一体化 GUI 工作流
├── time_clipper.py     # 时间段剪辑模块
├── crop_track.py       # 人物跟踪裁剪模块
├── video_io.py         # 视频导入/导出公共函数
├── utils.py            # 工具函数：时间解析、计算裁剪区域
├── requirements.txt    # Python 依赖列表
└── README.md           # 项目说明
```

## 使用说明

1. 安装依赖：
```bash
pip install -r requirements.txt
```

2. 安装系统工具 ffmpeg：
- macOS: `brew install ffmpeg`
- Ubuntu: `sudo apt update && sudo apt install ffmpeg`

3. 下载 YOLOv8 权重到项目根目录:
```bash
wget https://github.com/ultralytics/assets/releases/download/v0.0.0/yolov8n.pt
```

4. 运行一体化工作流：
```bash
python3 main_workflow.py
```

5. 在弹出的工作流界面，依次点击 **时间段剪辑**、**裁剪 & 跟踪**，最后使用系统播放器预览输出结果。

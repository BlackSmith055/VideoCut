#!/usr/bin/env python3
# crop_track.py

import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog
import cv2
from ultralytics import YOLO
from utils import compute_crop_box
from video_io import crop_and_pad

def detect_boxes(path):
    cap = cv2.VideoCapture(path)
    ret, frame = cap.read()
    cap.release()
    model = YOLO('yolov8n.pt')
    results = model(frame)[0]
    boxes = [tuple(map(int, r.xyxy[0].tolist())) for r in results.boxes if r.cls == 0]
    return frame, boxes

class CropTrackTool:
    def __init__(self, root):
        self.root = root
        root.title('2. 选择裁剪比例与跟踪人物')
        tk.Button(root, text='导入已剪好片段', command=self.select).pack(pady=5)
        self.lbl = tk.Label(root, text='未加载文件')
        self.lbl.pack()
        tk.Button(root, text='执行裁剪', command=self.on_crop).pack(pady=10)

    def select(self):
        path = filedialog.askopenfilename(filetypes=[('视频', '*.mp4 *.mov *.avi *.mkv')])
        if path:
            self.video = path
            self.lbl.config(text=path)

    def on_crop(self):
        if not hasattr(self, 'video'):
            messagebox.showwarning('未选择文件', '请先导入剪好后的片段')
            return
        frame, boxes = detect_boxes(self.video)
        opts = [f"{i+1}: {b}" for i, b in enumerate(boxes)]
        idx = simpledialog.askinteger('选择人物', '\n'.join(opts), minvalue=1, maxvalue=len(boxes))
        if not idx:
            return
        box = boxes[idx-1]
        ratio = simpledialog.askstring('输入比例', '请输入裁剪比例（3:4 或 1:1）：')
        if ratio not in ('3:4', '1:1'):
            messagebox.showerror('比例错误', '只支持 3:4 或 1:1')
            return
        crop_box = compute_crop_box(box, frame.shape[1], frame.shape[0], ratio)
        out = filedialog.asksaveasfilename(defaultextension='.mp4', filetypes=[('MP4', '*.mp4')])
        if not out:
            return
        crop_and_pad(self.video, crop_box, out)
        messagebox.showinfo('完成', '人物跟踪裁剪并加黑边完成')
        self.lbl.config(text=out)

if __name__ == '__main__':
    root = tk.Tk()
    CropTrackTool(root)
    root.mainloop()

# utils.py

def parse_time_str(time_str: str) -> float:
    parts = time_str.strip().split(":")
    if len(parts) == 1:
        return float(parts[0])
    elif len(parts) == 2:
        m, s = parts
        return int(m) * 60 + float(s)
    elif len(parts) == 3:
        h, m, s = parts
        return int(h) * 3600 + int(m) * 60 + float(s)
    else:
        raise ValueError(f"无效时间格式: {time_str}")

def compute_crop_box(box, frame_w, frame_h, ratio):
    cx = (box[0] + box[2]) // 2
    cy = (box[1] + box[3]) // 2
    if ratio == '3:4':
        w = min(frame_w, frame_h * 3/4)
        h = w * 4/3
    else:
        w = h = min(frame_w, frame_h)
    x1 = int(max(0, cx - w/2))
    y1 = int(max(0, cy - h/2))
    x2 = int(min(frame_w, x1 + w))
    y2 = int(min(frame_h, y1 + h))
    return x1, y1, x2, y2

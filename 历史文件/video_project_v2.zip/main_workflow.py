#!/usr/bin/env python3
# main_workflow.py

import tkinter as tk
from tkinter import messagebox
import subprocess

# Launch individual modules as subprocesses
def launch_module(script):
    subprocess.Popen(['python3', script])

class WorkflowApp:
    def __init__(self, root):
        self.root = root
        root.title('视频剪辑一体化工作流')
        tk.Button(root, text='1. 时间段剪辑', command=lambda: launch_module('time_clipper.py')).pack(fill='x', pady=5)
        tk.Button(root, text='2. 裁剪 & 跟踪', command=lambda: launch_module('crop_track.py')).pack(fill='x', pady=5)
        tk.Button(root, text='3. 预览输出', command=self.preview).pack(fill='x', pady=5)
        tk.Button(root, text='退出', command=root.quit).pack(fill='x', pady=5)

    def preview(self):
        messagebox.showinfo('提示', '请使用系统视频播放器打开生成的 MP4 文件进行预览。')

if __name__ == '__main__':
    root = tk.Tk()
    WorkflowApp(root)
    root.mainloop()

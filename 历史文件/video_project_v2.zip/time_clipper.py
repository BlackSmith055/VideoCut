#!/usr/bin/env python3
# time_clipper.py

import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from utils import parse_time_str
from video_io import extract_segment

class TimeClipTool:
    def __init__(self, root):
        self.root = root
        root.title('1. 导入视频并剪辑时间')
        self.video = None
        tk.Button(root, text='导入视频', command=self.select).pack(pady=5)
        self.lbl = tk.Label(root, text='未加载文件')
        self.lbl.pack()
        tk.Label(root, text='开始时间 (SS/MM:SS/HH:MM:SS):').pack()
        self.e_start = tk.Entry(root)
        self.e_start.pack()
        tk.Label(root, text='结束时间 (SS/MM:SS/HH:MM:SS):').pack()
        self.e_end = tk.Entry(root)
        self.e_end.pack()
        tk.Button(root, text='执行剪辑', command=self.on_clip).pack(pady=10)
        self.pb = ttk.Progressbar(root, length=300)
        self.pb.pack(pady=5)

    def select(self):
        path = filedialog.askopenfilename(filetypes=[('视频', '*.mp4 *.mov *.avi *.mkv')])
        if path:
            self.video = path
            self.lbl.config(text=path)

    def on_clip(self):
        if not self.video:
            messagebox.showwarning('未选择视频', '请先导入视频文件')
            return
        try:
            s = parse_time_str(self.e_start.get())
            e = parse_time_str(self.e_end.get())
        except ValueError as ex:
            messagebox.showerror('格式错误', str(ex))
            return
        if e <= s:
            messagebox.showerror('输入错误', '结束时间必须大于开始时间')
            return
        out = filedialog.asksaveasfilename(defaultextension='.mp4', filetypes=[('MP4', '*.mp4')])
        if not out:
            return
        def task():
            extract_segment(self.video, s, e, out)
            messagebox.showinfo('完成', '时间段剪辑完成')
        threading.Thread(target=task, daemon=True).start()

if __name__ == '__main__':
    root = tk.Tk()
    TimeClipTool(root)
    root.mainloop()
